const api = {
  url: 'http://localhost:3000/api',
  token: '',
};

export default api;
