export const LIST_PRODUCTS = 'product/LIST_PRODUCTS';

export const listProducts = payload => ({
  type: LIST_PRODUCTS,
  payload,
});
